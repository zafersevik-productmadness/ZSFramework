//
//  Greeter.h
//  ZSFramework
//
//  Created by Zafer Sevik on 03/04/2020.
//  Copyright © 2020 Zafer Sevik. All rights reserved.
//

@interface Greeter : NSObject

-(void) greet:(NSString*) name;

@end
