//
//  ZSFramework.h
//  ZSFramework
//
//  Created by Zafer Sevik on 03/04/2020.
//  Copyright © 2020 Zafer Sevik. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for ZSFramework.
FOUNDATION_EXPORT double ZSFrameworkVersionNumber;

//! Project version string for ZSFramework.
FOUNDATION_EXPORT const unsigned char ZSFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZSFramework/PublicHeader.h>


